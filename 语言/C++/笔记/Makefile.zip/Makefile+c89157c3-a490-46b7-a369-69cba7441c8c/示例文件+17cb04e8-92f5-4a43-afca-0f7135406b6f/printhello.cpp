#include <iostream>
#include "functions.h"

using namespace std;

void printhello()
{
    int i;
    cout << "Hello World!" << endl;
}